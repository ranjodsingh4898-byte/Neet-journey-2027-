# NEET 2027 Study Journey — Android App Project

## What is included
- Android Studio project
- Phone-first NEET 2027 study dashboard
- Physics 20-lecture backlog tracker
- Study-hour tracking
- Digital drawing canvas
- Image annotation/export
- Practice-test interface
- AI tutor interface placeholder
- Login interface placeholder
- Notification permission setup

## Open/build
1. Install Android Studio.
2. Open this folder as an existing Gradle project.
3. Let Android Studio sync Gradle.
4. Connect an Android phone or use an emulator.
5. Press Run.

## Important next development
The current app is a functional front-end prototype packaged as an Android app shell.
For production we still need:
- real account authentication
- secure cloud database/storage
- full PDF rendering + multi-page annotation
- verified NTA/NEET update feed and push notifications
- licensed/officially sourced PYQ and NCERT content
- secure AI backend/API
- full mock-test engine and analytics
