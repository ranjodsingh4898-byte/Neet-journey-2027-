# Build the APK using only your phone

1. Create a private GitHub repository.
2. Upload all files in this project to the repository (including `.github/workflows/build.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build NEET 2027 APK**.
5. Tap **Run workflow**.
6. When it finishes successfully, open the workflow run and download the artifact named **NEET2027-StudyJourney-debug**.
7. Extract the downloaded artifact and tap the `.apk` file to install it.

This is a debug APK of the current prototype.
